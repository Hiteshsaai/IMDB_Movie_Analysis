
IMDB Movie Analaysis
====================

This is a dataset of the movies and their budget,revenue,gender,rating
and reviwes from the imdb. From the given dataset i would like to ask
some questions, so that it would be helpful in connecting people with
their type of movie, so that the movie business can be imporved.

QUESTIONS
---------

-  Highest and lowerst Number of movies released in which year ?
-  Which genre movie has the Highest voting average ?
-  Which genre movies getting the Highest revenue ?
-  Which genre movies mostly liked by the people ?
-  Does the popularity of the movies depends on the runtime of the
   movie?
-  Does the movie with higher budget yields high revenue?
-  How many number of movies have been release each year in each genre?
-  Which heros has made the most contribution in movies in terms of
   revenue?
-  Which director has made the most contribution in movies in terms of
   revenue?

.. code:: ipython3

    import pandas as pd 
    import numpy as np
    import matplotlib.pyplot as plt 
    import seaborn as sns 
    import itertools
    %matplotlib inline 
    movies= pd.read_csv("tmdb-movies.csv")
    movies.head(2)




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>id</th>
          <th>imdb_id</th>
          <th>popularity</th>
          <th>budget</th>
          <th>revenue</th>
          <th>original_title</th>
          <th>cast</th>
          <th>homepage</th>
          <th>director</th>
          <th>tagline</th>
          <th>...</th>
          <th>release_date</th>
          <th>vote_count</th>
          <th>vote_average</th>
          <th>release_year</th>
          <th>budget_adj</th>
          <th>revenue_adj</th>
          <th>Unnamed: 21</th>
          <th>Unnamed: 22</th>
          <th>Unnamed: 23</th>
          <th>Unnamed: 24</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>135397</td>
          <td>tt0369610</td>
          <td>32.985763</td>
          <td>150000000</td>
          <td>1513528810</td>
          <td>Jurassic World</td>
          <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
          <td>http://www.jurassicworld.com/</td>
          <td>Colin Trevorrow</td>
          <td>The park is open.</td>
          <td>...</td>
          <td>6/9/15</td>
          <td>5562</td>
          <td>6.5</td>
          <td>2015</td>
          <td>137999939.280026</td>
          <td>1.392446e+09</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>1</th>
          <td>76341</td>
          <td>tt1392190</td>
          <td>28.419936</td>
          <td>150000000</td>
          <td>378436354</td>
          <td>Mad Max: Fury Road</td>
          <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
          <td>http://www.madmaxmovie.com/</td>
          <td>George Miller</td>
          <td>What a Lovely Day.</td>
          <td>...</td>
          <td>5/13/15</td>
          <td>6185</td>
          <td>7.1</td>
          <td>2015</td>
          <td>137999939.280026</td>
          <td>3.481613e+08</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
      </tbody>
    </table>
    <p>2 rows × 25 columns</p>
    </div>



Assessing & Cleaning the Data
=============================

.. code:: ipython3

    movies.shape




.. parsed-literal::

    (10866, 25)



.. code:: ipython3

    movies.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10866 entries, 0 to 10865
    Data columns (total 25 columns):
    id                      10866 non-null int64
    imdb_id                 10856 non-null object
    popularity              10866 non-null float64
    budget                  10866 non-null int64
    revenue                 10866 non-null int64
    original_title          10866 non-null object
    cast                    10790 non-null object
    homepage                2936 non-null object
    director                10822 non-null object
    tagline                 8040 non-null object
    keywords                9374 non-null object
    overview                10860 non-null object
    runtime                 10866 non-null object
    genres                  10843 non-null object
    production_companies    9845 non-null object
    release_date            10858 non-null object
    vote_count              10866 non-null object
    vote_average            10865 non-null object
    release_year            10866 non-null object
    budget_adj              10866 non-null object
    revenue_adj             10866 non-null float64
    Unnamed: 21             41 non-null float64
    Unnamed: 22             4 non-null float64
    Unnamed: 23             3 non-null float64
    Unnamed: 24             1 non-null float64
    dtypes: float64(6), int64(3), object(16)
    memory usage: 2.1+ MB


.. code:: ipython3

    #Removing the column which are not required for analysis
    movies.drop(['tagline','keywords','overview','budget_adj','revenue_adj','Unnamed: 21','Unnamed: 22','Unnamed: 23','Unnamed: 24'],axis=1, inplace=True) 
    movies.head(2)




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>id</th>
          <th>imdb_id</th>
          <th>popularity</th>
          <th>budget</th>
          <th>revenue</th>
          <th>original_title</th>
          <th>cast</th>
          <th>homepage</th>
          <th>director</th>
          <th>runtime</th>
          <th>genres</th>
          <th>production_companies</th>
          <th>release_date</th>
          <th>vote_count</th>
          <th>vote_average</th>
          <th>release_year</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>135397</td>
          <td>tt0369610</td>
          <td>32.985763</td>
          <td>150000000</td>
          <td>1513528810</td>
          <td>Jurassic World</td>
          <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
          <td>http://www.jurassicworld.com/</td>
          <td>Colin Trevorrow</td>
          <td>124</td>
          <td>Action|Adventure|Science Fiction|Thriller</td>
          <td>Universal Studios|Amblin Entertainment|Legenda...</td>
          <td>6/9/15</td>
          <td>5562</td>
          <td>6.5</td>
          <td>2015</td>
        </tr>
        <tr>
          <th>1</th>
          <td>76341</td>
          <td>tt1392190</td>
          <td>28.419936</td>
          <td>150000000</td>
          <td>378436354</td>
          <td>Mad Max: Fury Road</td>
          <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
          <td>http://www.madmaxmovie.com/</td>
          <td>George Miller</td>
          <td>120</td>
          <td>Action|Adventure|Science Fiction|Thriller</td>
          <td>Village Roadshow Pictures|Kennedy Miller Produ...</td>
          <td>5/13/15</td>
          <td>6185</td>
          <td>7.1</td>
          <td>2015</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #converting the column with interger or float from string object datatype to float
    movies.runtime = pd.to_numeric(movies.runtime,errors= 'coerce')
    movies.vote_count = pd.to_numeric(movies.vote_count,errors='coerce')
    movies.vote_average = pd.to_numeric(movies.vote_average,errors='coerce')
    movies.budget = movies.budget.astype(float)
    movies.revenue = movies.revenue.astype(float)

.. code:: ipython3

    #creating gener and lead_role column for analysis & replaceing the genres string values seperated with comma.
    movies['genre'] = movies.genres.str.split('|',expand= True)[0]
    movies['lead_role'] = movies.cast.str.split('|',expand=True)[0]
    movies['genres'] = movies['genres'].str.replace('|',',')
    movies.head(2)




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>id</th>
          <th>imdb_id</th>
          <th>popularity</th>
          <th>budget</th>
          <th>revenue</th>
          <th>original_title</th>
          <th>cast</th>
          <th>homepage</th>
          <th>director</th>
          <th>runtime</th>
          <th>genres</th>
          <th>production_companies</th>
          <th>release_date</th>
          <th>vote_count</th>
          <th>vote_average</th>
          <th>release_year</th>
          <th>genre</th>
          <th>lead_role</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>135397</td>
          <td>tt0369610</td>
          <td>32.985763</td>
          <td>150000000.0</td>
          <td>1.513529e+09</td>
          <td>Jurassic World</td>
          <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
          <td>http://www.jurassicworld.com/</td>
          <td>Colin Trevorrow</td>
          <td>124.0</td>
          <td>Action,Adventure,Science Fiction,Thriller</td>
          <td>Universal Studios|Amblin Entertainment|Legenda...</td>
          <td>6/9/15</td>
          <td>5562.0</td>
          <td>6.5</td>
          <td>2015</td>
          <td>Action</td>
          <td>Chris Pratt</td>
        </tr>
        <tr>
          <th>1</th>
          <td>76341</td>
          <td>tt1392190</td>
          <td>28.419936</td>
          <td>150000000.0</td>
          <td>3.784364e+08</td>
          <td>Mad Max: Fury Road</td>
          <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
          <td>http://www.madmaxmovie.com/</td>
          <td>George Miller</td>
          <td>120.0</td>
          <td>Action,Adventure,Science Fiction,Thriller</td>
          <td>Village Roadshow Pictures|Kennedy Miller Produ...</td>
          <td>5/13/15</td>
          <td>6185.0</td>
          <td>7.1</td>
          <td>2015</td>
          <td>Action</td>
          <td>Tom Hardy</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #To remove the duplicates
    movies.drop_duplicates(inplace=True)

.. code:: ipython3

    #convert all the budget and revenue amount in Billion Dollar Amount
    movies.budget = movies.budget/1000000000 
    movies.revenue = movies.revenue/1000000000 
    movies.head(4)




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>id</th>
          <th>imdb_id</th>
          <th>popularity</th>
          <th>budget</th>
          <th>revenue</th>
          <th>original_title</th>
          <th>cast</th>
          <th>homepage</th>
          <th>director</th>
          <th>runtime</th>
          <th>genres</th>
          <th>production_companies</th>
          <th>release_date</th>
          <th>vote_count</th>
          <th>vote_average</th>
          <th>release_year</th>
          <th>genre</th>
          <th>lead_role</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>135397</td>
          <td>tt0369610</td>
          <td>32.985763</td>
          <td>0.15</td>
          <td>1.513529</td>
          <td>Jurassic World</td>
          <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
          <td>http://www.jurassicworld.com/</td>
          <td>Colin Trevorrow</td>
          <td>124.0</td>
          <td>Action,Adventure,Science Fiction,Thriller</td>
          <td>Universal Studios|Amblin Entertainment|Legenda...</td>
          <td>6/9/15</td>
          <td>5562.0</td>
          <td>6.5</td>
          <td>2015</td>
          <td>Action</td>
          <td>Chris Pratt</td>
        </tr>
        <tr>
          <th>1</th>
          <td>76341</td>
          <td>tt1392190</td>
          <td>28.419936</td>
          <td>0.15</td>
          <td>0.378436</td>
          <td>Mad Max: Fury Road</td>
          <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
          <td>http://www.madmaxmovie.com/</td>
          <td>George Miller</td>
          <td>120.0</td>
          <td>Action,Adventure,Science Fiction,Thriller</td>
          <td>Village Roadshow Pictures|Kennedy Miller Produ...</td>
          <td>5/13/15</td>
          <td>6185.0</td>
          <td>7.1</td>
          <td>2015</td>
          <td>Action</td>
          <td>Tom Hardy</td>
        </tr>
        <tr>
          <th>2</th>
          <td>262500</td>
          <td>tt2908446</td>
          <td>13.112507</td>
          <td>0.11</td>
          <td>0.295238</td>
          <td>Insurgent</td>
          <td>Shailene Woodley|Theo James|Kate Winslet|Ansel...</td>
          <td>http://www.thedivergentseries.movie/#insurgent</td>
          <td>Robert Schwentke</td>
          <td>119.0</td>
          <td>Adventure,Science Fiction,Thriller</td>
          <td>Summit Entertainment|Mandeville Films|Red Wago...</td>
          <td>3/18/15</td>
          <td>2480.0</td>
          <td>6.3</td>
          <td>2015</td>
          <td>Adventure</td>
          <td>Shailene Woodley</td>
        </tr>
        <tr>
          <th>3</th>
          <td>140607</td>
          <td>tt2488496</td>
          <td>11.173104</td>
          <td>0.20</td>
          <td>2.068178</td>
          <td>Star Wars: The Force Awakens</td>
          <td>Harrison Ford|Mark Hamill|Carrie Fisher|Adam D...</td>
          <td>http://www.starwars.com/films/star-wars-episod...</td>
          <td>J.J. Abrams</td>
          <td>136.0</td>
          <td>Action,Adventure,Science Fiction,Fantasy</td>
          <td>Lucasfilm|Truenorth Productions|Bad Robot</td>
          <td>12/15/15</td>
          <td>5292.0</td>
          <td>7.5</td>
          <td>2015</td>
          <td>Action</td>
          <td>Harrison Ford</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #Renaming the buget and revenue column in billions
    movies = movies.rename(columns={'budget':'budget_in_billion','revenue':'revenue_in_billion'})

.. code:: ipython3

    #filtering the release_year and genre to required length for better analysis
    movies.release_year = movies.release_year.astype(str)
    movies = movies[movies['release_year'].str.len() == 4]
    movies = movies[movies['genre'].str.len() <= 15]
    movies.release_year = movies.release_year.astype(int)

Explorations Phase
==================

.. code:: ipython3

    #Release years and count from the data
    print("Total Number of Release Years:", movies.release_year.nunique())
    print("Release Years:", movies.release_year.unique())


.. parsed-literal::

    Total Number of Release Years: 56
    Release Years: [2015 2014 1977 2009 2010 1999 2001 2008 2011 2002 1994 2012 2003 1997 2013
     1985 2005 2006 2004 1972 1980 2007 1979 1984 1983 1995 1992 1981 1996 2000
     1982 1998 1989 1991 1988 1987 1968 1974 1975 1962 1964 1971 1990 1961 1960
     1976 1993 1967 1963 1986 1973 1970 1965 1969 1978 1966]


.. code:: ipython3

    # Basic analysis from the Data
    print ("Total number of movies:",movies.original_title.nunique())
    print ("Total number of Geners:",movies.genre.nunique())
    print ("Different Geners:",movies['genre'].unique())
    print ("Total number of directors:",movies['director'].nunique())


.. parsed-literal::

    Total number of movies: 10508
    Total number of Geners: 20
    Different Geners: ['Action' 'Adventure' 'Western' 'Science Fiction' 'Drama' 'Family' 'Comedy'
     'Crime' 'Romance' 'War' 'Mystery' 'Thriller' 'Fantasy' 'History'
     'Animation' 'Horror' 'Music' 'Documentary' 'TV Movie' 'Foreign']
    Total number of directors: 5039


.. code:: ipython3

    #to display the statistical values of all numerical data's
    movies.describe()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>id</th>
          <th>popularity</th>
          <th>budget_in_billion</th>
          <th>revenue_in_billion</th>
          <th>runtime</th>
          <th>vote_count</th>
          <th>vote_average</th>
          <th>release_year</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>10801.000000</td>
          <td>10801.000000</td>
          <td>10801.000000</td>
          <td>10801.000000</td>
          <td>10801.000000</td>
          <td>10801.000000</td>
          <td>10801.000000</td>
          <td>10801.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>65864.003796</td>
          <td>0.648130</td>
          <td>0.014672</td>
          <td>0.039923</td>
          <td>102.139061</td>
          <td>218.009444</td>
          <td>5.974058</td>
          <td>2001.312656</td>
        </tr>
        <tr>
          <th>std</th>
          <td>91963.444634</td>
          <td>1.002536</td>
          <td>0.030972</td>
          <td>0.117259</td>
          <td>31.290158</td>
          <td>576.976996</td>
          <td>0.933689</td>
          <td>12.814955</td>
        </tr>
        <tr>
          <th>min</th>
          <td>5.000000</td>
          <td>0.000065</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>10.000000</td>
          <td>1.500000</td>
          <td>1960.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>10590.000000</td>
          <td>0.208372</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>90.000000</td>
          <td>17.000000</td>
          <td>5.400000</td>
          <td>1995.000000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>20558.000000</td>
          <td>0.384557</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>99.000000</td>
          <td>38.000000</td>
          <td>6.000000</td>
          <td>2006.000000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>75190.000000</td>
          <td>0.715451</td>
          <td>0.015000</td>
          <td>0.024007</td>
          <td>111.000000</td>
          <td>146.000000</td>
          <td>6.600000</td>
          <td>2011.000000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>417859.000000</td>
          <td>32.985763</td>
          <td>0.425000</td>
          <td>2.781506</td>
          <td>900.000000</td>
          <td>9767.000000</td>
          <td>9.200000</td>
          <td>2015.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



**Highest and lowerst Number of movies released in which year ?** 
------------------------------------------------------------------

In this analysis i have used the "Release\_year" variable to identify
the number of movies released each year, So from the Bar graph analysis
it has been clear that most number of movies released on the year
**2014** and the least number of movies was released on **1961**.

.. code:: ipython3

    #Number of release in each year
    plt.figure(figsize=(25,20))
    sns.countplot(x='release_year',data=movies)
    plt.title("Number of Movies each Year")
    plt.show()



.. image:: output_17_0.png


**Which Genre Movie Has The Highest voting Average ?** 
-------------------------------------------------------

In this analysis i have used the *genre* and *vote\_average* variables
to determine which movie genre gets the highest voting average, and from
the visualization it is clear that **Documentary** genre has the higest
number of voting average followed by Music, Animation and Foregin
movies.

.. code:: ipython3

    #comparision graph between the genre & vote_average
    plt.figure(figsize = (25,10))
    sns.barplot(x='genre',y='vote_average',data = movies)
    plt.show()



.. image:: output_19_0.png


Which genre movies has the highest popularity amoung people? 
-------------------------------------------------------------

In this analysis i have used the genre and the popularity variable to
determine the type of genre liked mostly by people, and from the
visualization it is clear that **Adventure** movies has the highest
populartiy with the rating of 12 which is followed by the science
fiction moives with 11 rating and rest all fall's below 10.

.. code:: ipython3

    #comparision between the genre and popularity
    plt.figure(figsize=(25,10))
    sns.barplot(x='genre',y='popularity',data=movies)
    plt.show()



.. image:: output_21_0.png


Which Movie Genre Has The Highest Investment? 
----------------------------------------------

In this visualization i have used the *genre* and *budget\_in\_billion*
variables for analysing the movie gener has given the higest investment
all time. From the bar plot it is very clear that higest investment
buget is for the **Adventure** Films.

.. code:: ipython3

    #comparision between different genres and their budget
    plt.figure(figsize=(25,10))
    sns.barplot(x='genre',y='budget_in_billion',data=movies)
    plt.show()



.. image:: output_23_0.png


Which Movie Genre has yield the Highest Revenue ? 
--------------------------------------------------

In this visualization *genre* and *revenue\_in\_billion* variables are
used for analysing the type of genre yields the highest revenue and from
the analysis it is very Transparent that **Adventure** Moives get's the
higest revenue in averge with 120 Million Doller.

.. code:: ipython3

    #comparision between the different genres and their revenue
    plt.figure(figsize=(25,10))
    sns.barplot(x='genre',y='revenue_in_billion',data=movies)
    plt.show()



.. image:: output_25_0.png


Does the popularity of the movies depends on the runtime of the movie? 
-----------------------------------------------------------------------

For this analysis i have used the *runtime* and *popularity* variable to
analyse whether the runtime of the movie affects the popularity of the
movie and from the analysis it is very clear that the run time of the
movie do affect the popularity and from the scatter plot it has a
negetive correlation and movies with higest popularity has a runtime
between **120 to 150 minutes** of runtime.

.. code:: ipython3

    #scatter polt to analyse whether the popularity based on the movie runtime 
    plt.figure(figsize=(20,10))
    sns.lmplot(x='runtime',y='popularity',data= movies,fit_reg = True)
    plt.show();



.. parsed-literal::

    <matplotlib.figure.Figure at 0x7efe687014a8>



.. image:: output_27_1.png


Does the movie with higher budget yields high revenue? 
-------------------------------------------------------

For this analysis the budget and the revenue variable have been used to
analyse whether moives with the higher revenue depends on the budget of
the movie. So, the scatter polt gives a negative correlation and yes the
revenue of the movie mostly depends on the budget of the movie, but not
always because there are some outliers in the plot where higher buget
movie has yield less revenue but as it is a outlier we dont need to take
much in to consideration, so the revenue of the movie depends on the
budget of the movie.

.. code:: ipython3

    #scatter plot to analyse whether revenue of a movie based on the budget  
    plt.figure(figsize=(20,10))
    sns.lmplot(x='budget_in_billion',y='revenue_in_billion',data= movies,fit_reg=True)
    plt.show();



.. parsed-literal::

    <matplotlib.figure.Figure at 0x7efe686c6a90>



.. image:: output_29_1.png


.. code:: ipython3

    #Dataframe on the mean popularity for each genre from highest to lowest
    movies.groupby('genre',as_index=False)['popularity'].mean().sort_values('popularity',ascending = False)





.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>genre</th>
          <th>popularity</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1</th>
          <td>Adventure</td>
          <td>1.219548</td>
        </tr>
        <tr>
          <th>15</th>
          <td>Science Fiction</td>
          <td>1.073693</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Fantasy</td>
          <td>0.866243</td>
        </tr>
        <tr>
          <th>0</th>
          <td>Action</td>
          <td>0.838053</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Animation</td>
          <td>0.812961</td>
        </tr>
        <tr>
          <th>18</th>
          <td>War</td>
          <td>0.767041</td>
        </tr>
        <tr>
          <th>10</th>
          <td>History</td>
          <td>0.764636</td>
        </tr>
        <tr>
          <th>7</th>
          <td>Family</td>
          <td>0.730987</td>
        </tr>
        <tr>
          <th>14</th>
          <td>Romance</td>
          <td>0.704157</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Crime</td>
          <td>0.695163</td>
        </tr>
        <tr>
          <th>19</th>
          <td>Western</td>
          <td>0.690646</td>
        </tr>
        <tr>
          <th>17</th>
          <td>Thriller</td>
          <td>0.674897</td>
        </tr>
        <tr>
          <th>13</th>
          <td>Mystery</td>
          <td>0.596896</td>
        </tr>
        <tr>
          <th>6</th>
          <td>Drama</td>
          <td>0.552280</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Comedy</td>
          <td>0.537677</td>
        </tr>
        <tr>
          <th>11</th>
          <td>Horror</td>
          <td>0.467835</td>
        </tr>
        <tr>
          <th>12</th>
          <td>Music</td>
          <td>0.447730</td>
        </tr>
        <tr>
          <th>16</th>
          <td>TV Movie</td>
          <td>0.246190</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Documentary</td>
          <td>0.175862</td>
        </tr>
        <tr>
          <th>9</th>
          <td>Foreign</td>
          <td>0.167124</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #DataFrame on the mean voting avergare for each genre from highest to the lowest
    movies.groupby('genre',as_index=False)['vote_average'].mean().sort_values('vote_average',ascending = False)





.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>genre</th>
          <th>vote_average</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>5</th>
          <td>Documentary</td>
          <td>6.924766</td>
        </tr>
        <tr>
          <th>12</th>
          <td>Music</td>
          <td>6.605000</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Animation</td>
          <td>6.416000</td>
        </tr>
        <tr>
          <th>10</th>
          <td>History</td>
          <td>6.381818</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Crime</td>
          <td>6.215040</td>
        </tr>
        <tr>
          <th>6</th>
          <td>Drama</td>
          <td>6.199673</td>
        </tr>
        <tr>
          <th>18</th>
          <td>War</td>
          <td>6.183051</td>
        </tr>
        <tr>
          <th>14</th>
          <td>Romance</td>
          <td>6.133871</td>
        </tr>
        <tr>
          <th>19</th>
          <td>Western</td>
          <td>6.080952</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Adventure</td>
          <td>6.051966</td>
        </tr>
        <tr>
          <th>15</th>
          <td>Science Fiction</td>
          <td>5.958685</td>
        </tr>
        <tr>
          <th>7</th>
          <td>Family</td>
          <td>5.945833</td>
        </tr>
        <tr>
          <th>13</th>
          <td>Mystery</td>
          <td>5.900800</td>
        </tr>
        <tr>
          <th>9</th>
          <td>Foreign</td>
          <td>5.900000</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Comedy</td>
          <td>5.882366</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Fantasy</td>
          <td>5.794834</td>
        </tr>
        <tr>
          <th>16</th>
          <td>TV Movie</td>
          <td>5.793590</td>
        </tr>
        <tr>
          <th>0</th>
          <td>Action</td>
          <td>5.753190</td>
        </tr>
        <tr>
          <th>17</th>
          <td>Thriller</td>
          <td>5.637423</td>
        </tr>
        <tr>
          <th>11</th>
          <td>Horror</td>
          <td>5.319472</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #List of all unique Genre of movies
    unique_genres = movies['genres'].unique()
    individual_genres = []
    for genre in unique_genres:
        individual_genres.append(genre.split(','))
    individual_genres = list(itertools.chain.from_iterable(individual_genres))
    individual_genres = set(individual_genres)
    
    individual_genres




.. parsed-literal::

    {'Action',
     'Adventure',
     'Animation',
     'Comedy',
     'Crime',
     'Documentary',
     'Drama',
     'Family',
     'Fantasy',
     'Foreign',
     'History',
     'Horror',
     'Music',
     'Mystery',
     'Romance',
     'Science Fiction',
     'TV Movie',
     'Thriller',
     'War',
     'Western'}



Which Gener Movies released the most ? 
---------------------------------------

For this analysis i have used the each genre type in to seperate data
frame to calcuate the total numbe of movies in each genre and from that
analysis it is clear that **Drama** genre movie has been released the
most with 4647 movies. ## Which Year has Most Number of Movies Release
for each Genre? Thriller : 2014 , TV Movies: 2015, Fantasy: 2009,
Documentary: 2014, Action: 2014, Crime: 2013, Western: 1970&1994
Romance: 2010, War: 2014, Family: 2011, Foregin: 2013, Drama: 2014,
Adventure: 2009, Horror: 2015, Comedy : 2009, Animation: 2010, Music:
2015, History: 2008, Mystery: 2009, Science Fiction: 2015.

.. code:: ipython3

    #Total number of movies on each genre
    #A detailed analysis on total movie release in each year for each genre
    print ( "Number of movies in each genre \n")
    for genre in individual_genres:
        seperate_genre = movies['genres'].str.contains(genre).fillna(False)
        plt.figure(figsize=(15,10))
        plt.xlabel('Year')
        plt.ylabel('Number of Movies Made')
        plt.title(str(genre))
        movies[seperate_genre].release_year.value_counts().sort_index().plot(kind='bar',color ='b',alpha=0.5,rot=45)
        print(genre, len(movies[seperate_genre]))


.. parsed-literal::

    Number of movies in each genre 
    
    Thriller 2898
    TV Movie 167
    Fantasy 914
    Documentary 515
    Action 2375
    Crime 1351
    Western 165
    Romance 1704
    War 268
    Family 1226
    Foreign 187
    Drama 4745
    Adventure 1465
    Horror 1629
    Comedy 3778
    Animation 696
    Music 407
    History 332
    Mystery 809
    Science Fiction 1222



.. image:: output_34_1.png



.. image:: output_34_2.png



.. image:: output_34_3.png



.. image:: output_34_4.png



.. image:: output_34_5.png



.. image:: output_34_6.png



.. image:: output_34_7.png



.. image:: output_34_8.png



.. image:: output_34_9.png



.. image:: output_34_10.png



.. image:: output_34_11.png



.. image:: output_34_12.png



.. image:: output_34_13.png



.. image:: output_34_14.png



.. image:: output_34_15.png



.. image:: output_34_16.png



.. image:: output_34_17.png



.. image:: output_34_18.png



.. image:: output_34_19.png



.. image:: output_34_20.png


**Calcuated the Percentage of movies released in each genre **
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    # calcuating Percentage of movies released on each genre
    genre_percent = np.zeros(len(individual_genres))
    i =0
    for genre in individual_genres:
        current_genre = movies['genres'].str.contains(genre).fillna(False)
        percent = len(movies[current_genre])/10842 * 100
        genre_percent[i] = percent
        i += 1
        print (genre, percent)


.. parsed-literal::

    Thriller 26.72938572219148
    TV Movie 1.5403062165652093
    Fantasy 8.430178933776055
    Documentary 4.750046116952592
    Action 21.90555248109205
    Crime 12.460800590296992
    Western 1.5218594355285002
    Romance 15.71665744327615
    War 2.4718686589190186
    Family 11.307876775502674
    Foreign 1.7247740269323002
    Drama 43.76498800959233
    Adventure 13.512267109389411
    Horror 15.024903154399558
    Comedy 34.845969378343476
    Animation 6.419479800774765
    Music 3.753919940970301
    History 3.0621656520937095
    Mystery 7.461722929348828
    Science Fiction 11.270983213429256


.. code:: ipython3

    #DataFrame for clear visualization and to make Analysis on them
    genre_df = pd.DataFrame(genre_percent,index = individual_genres,columns=['percentage'])
    genre_df['percentage'] = genre_df['percentage'].round(2)
    genre_df 




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>percentage</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>Thriller</th>
          <td>26.73</td>
        </tr>
        <tr>
          <th>TV Movie</th>
          <td>1.54</td>
        </tr>
        <tr>
          <th>Fantasy</th>
          <td>8.43</td>
        </tr>
        <tr>
          <th>Documentary</th>
          <td>4.75</td>
        </tr>
        <tr>
          <th>Action</th>
          <td>21.91</td>
        </tr>
        <tr>
          <th>Crime</th>
          <td>12.46</td>
        </tr>
        <tr>
          <th>Western</th>
          <td>1.52</td>
        </tr>
        <tr>
          <th>Romance</th>
          <td>15.72</td>
        </tr>
        <tr>
          <th>War</th>
          <td>2.47</td>
        </tr>
        <tr>
          <th>Family</th>
          <td>11.31</td>
        </tr>
        <tr>
          <th>Foreign</th>
          <td>1.72</td>
        </tr>
        <tr>
          <th>Drama</th>
          <td>43.76</td>
        </tr>
        <tr>
          <th>Adventure</th>
          <td>13.51</td>
        </tr>
        <tr>
          <th>Horror</th>
          <td>15.02</td>
        </tr>
        <tr>
          <th>Comedy</th>
          <td>34.85</td>
        </tr>
        <tr>
          <th>Animation</th>
          <td>6.42</td>
        </tr>
        <tr>
          <th>Music</th>
          <td>3.75</td>
        </tr>
        <tr>
          <th>History</th>
          <td>3.06</td>
        </tr>
        <tr>
          <th>Mystery</th>
          <td>7.46</td>
        </tr>
        <tr>
          <th>Science Fiction</th>
          <td>11.27</td>
        </tr>
      </tbody>
    </table>
    </div>



Top five Genre of movies contribution 
--------------------------------------

Here for this analysis i have calcuated the movies contribution
percentage on each genre from the previous cell and from that i have
plotted the top 5 genres contribution in a pie chart for a better
visualiation in percentage among the top 5 and from that the most
contribution of movies is by the **Drama** and **Comedy** where they
differ only by 5.7 percent.

.. code:: ipython3

    #Pie chart analysis on the top 5 genres based on the total number of movies
    explode = (0.05, 0.05, 0.08, 0.1, 0.12)
    colors = ['#ff3232', '#ff4c4c', '#ff6666', '#ff7f7f', '#ff9999' ]
    genre_df.sort_values(by='percentage', ascending=False).head(5).plot.pie(legend=False, subplots=True, autopct='%.2f%%', figsize=(8,8), explode=explode, colors=colors)
    plt.ylabel('')
    plt.title('Percent of Total Movies Made from Top 5 Genres', weight='bold', fontsize=16)




.. parsed-literal::

    <matplotlib.text.Text at 0x7efe4e71a860>




.. image:: output_39_1.png


**Calcuated the Revenue obtained by each Genre of movie in percentage **
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    #Total Revenue obtained by each genre
    genre_revenue_percent = np.zeros(len(individual_genres))
    i = 0
    for genre in individual_genres:
        current_genre = movies['genres'].str.contains(genre).fillna(False)
        revenue_percent = movies[current_genre].revenue_in_billion.sum()/movies['revenue_in_billion'].sum() * 100
        genre_revenue_percent[i] = revenue_percent
        i += 1
        print (genre,revenue_percent)


.. parsed-literal::

    Thriller 28.04589135255545
    TV Movie 0.009740018211932247
    Fantasy 20.45814612556723
    Documentary 0.21850702683595125
    Action 40.119461115628624
    Crime 13.231441770798769
    Western 1.0931632985657296
    Romance 14.12283051953406
    War 2.9652379661960144
    Family 20.649511901041976
    Foreign 0.06628927664467053
    Drama 32.046780565273274
    Adventure 38.51467192109378
    Horror 6.378150419067804
    Comedy 32.92922157601089
    Animation 12.192833111528124
    Music 2.7033841747348375
    History 2.4639840331114122
    Mystery 7.518547935720401
    Science Fiction 19.93106957957271


.. code:: ipython3

    #Same as before made a DataFrame for clear visualization and to make Analysis on them
    genre_revenue_df = pd.DataFrame(genre_revenue_percent, index = individual_genres,columns=['percentage'])
    genre_revenue_df 




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>percentage</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>Thriller</th>
          <td>28.045891</td>
        </tr>
        <tr>
          <th>TV Movie</th>
          <td>0.009740</td>
        </tr>
        <tr>
          <th>Fantasy</th>
          <td>20.458146</td>
        </tr>
        <tr>
          <th>Documentary</th>
          <td>0.218507</td>
        </tr>
        <tr>
          <th>Action</th>
          <td>40.119461</td>
        </tr>
        <tr>
          <th>Crime</th>
          <td>13.231442</td>
        </tr>
        <tr>
          <th>Western</th>
          <td>1.093163</td>
        </tr>
        <tr>
          <th>Romance</th>
          <td>14.122831</td>
        </tr>
        <tr>
          <th>War</th>
          <td>2.965238</td>
        </tr>
        <tr>
          <th>Family</th>
          <td>20.649512</td>
        </tr>
        <tr>
          <th>Foreign</th>
          <td>0.066289</td>
        </tr>
        <tr>
          <th>Drama</th>
          <td>32.046781</td>
        </tr>
        <tr>
          <th>Adventure</th>
          <td>38.514672</td>
        </tr>
        <tr>
          <th>Horror</th>
          <td>6.378150</td>
        </tr>
        <tr>
          <th>Comedy</th>
          <td>32.929222</td>
        </tr>
        <tr>
          <th>Animation</th>
          <td>12.192833</td>
        </tr>
        <tr>
          <th>Music</th>
          <td>2.703384</td>
        </tr>
        <tr>
          <th>History</th>
          <td>2.463984</td>
        </tr>
        <tr>
          <th>Mystery</th>
          <td>7.518548</td>
        </tr>
        <tr>
          <th>Science Fiction</th>
          <td>19.931070</td>
        </tr>
      </tbody>
    </table>
    </div>



Total Percentage Revenue Obtained by Top 5 Genres 
--------------------------------------------------

I have calcuated the percentage of Revenue obtained by individual genres
in the previous cell and from that i have plotted the pie chart for the
top 5 genres for a better visualiation to compare their contribution to
a extent and from that analysis Action, Adventure and Comedy are nearby
each other in their contribution and amoung these Action movies yields
the most revenue.

.. code:: ipython3

    #Pie chart analysis on the top 5 genres based on the revenue
    explode = (0.05, 0.05, 0.08, 0.1, 0.12)
    colors = ['#ff3232', '#ff4c4c', '#ff6666', '#ff7f7f', '#ff9999' ]
    genre_revenue_df.sort_values(by='percentage',ascending=False).head(5).plot.pie(legend=False, subplots=True, autopct='%.2f%%', figsize=(8,8), explode=explode,colors = colors)
    plt.ylabel('')
    plt.title('Percent of Total Revenue Made from Top 5 Genres', weight='bold', fontsize=16)




.. parsed-literal::

    <matplotlib.text.Text at 0x7efe4edd29b0>




.. image:: output_44_1.png


**Sorted out the top 10 Directors based on their movie count and have calculated the total revenue obtained from them.**
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    # Obtaining the first 10 directors based on the numbe of movies directed
    most_active_director = movies.director.value_counts().head(10)
    most_active_directors = most_active_director.index


.. code:: ipython3

    # Obtaining the Revenues given by these top 10 directors in Billions
    director_revenue_total = np.zeros(len(most_active_directors))
    i =0 
    for dirct in most_active_directors:
        current_director = movies['director'].str.contains(dirct).fillna(False)
        director_revenue = movies[current_director].revenue_in_billion.sum()
        director_revenue_total[i] = director_revenue
        i += 1
        print (dirct,director_revenue)


.. parsed-literal::

    Woody Allen 0.8520244779999999
    Clint Eastwood 2.8248712549999997
    Martin Scorsese 1.9672453189999994
    Steven Spielberg 9.048014690999999
    Ridley Scott 3.6499964800000013
    Ron Howard 3.484471847
    Steven Soderbergh 2.1593816660000003
    Joel Schumacher 1.525356531
    Brian De Palma 1.0251171700000001
    Tim Burton 3.782609685


.. code:: ipython3

    #DataFrame for the clear Visualization and Analysis
    dirct_revenue_df = pd.DataFrame(director_revenue_total,index = most_active_directors,columns=['Revenue'])
    dirct_revenue_df




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Revenue</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>Woody Allen</th>
          <td>0.852024</td>
        </tr>
        <tr>
          <th>Clint Eastwood</th>
          <td>2.824871</td>
        </tr>
        <tr>
          <th>Martin Scorsese</th>
          <td>1.967245</td>
        </tr>
        <tr>
          <th>Steven Spielberg</th>
          <td>9.048015</td>
        </tr>
        <tr>
          <th>Ridley Scott</th>
          <td>3.649996</td>
        </tr>
        <tr>
          <th>Ron Howard</th>
          <td>3.484472</td>
        </tr>
        <tr>
          <th>Steven Soderbergh</th>
          <td>2.159382</td>
        </tr>
        <tr>
          <th>Joel Schumacher</th>
          <td>1.525357</td>
        </tr>
        <tr>
          <th>Brian De Palma</th>
          <td>1.025117</td>
        </tr>
        <tr>
          <th>Tim Burton</th>
          <td>3.782610</td>
        </tr>
      </tbody>
    </table>
    </div>



Top 10 Directors who has made Highest Revenue Percentage overall 
-----------------------------------------------------------------

In this analysis i have calcuated the percentage of revenue contribution
of individual directors in the above cell, and for a better analysis i
have sorted out the top 10 directors among them and plotted a pie chart
to get a better visualization, from the visualization it is very much
outstanding that **Steven Spielberg** has made the higest contribution
with 29.84% and followed by **Tim Burton** with 12.48%.

.. code:: ipython3

    #pie chart analysis on the directors with highest to the lowest
    explode = np.linspace(0,0.4, 10)
    colors = ['#ff3232', '#ff4c4c', '#ff6666', '#ff7f7f', '#ff9999' ]
    dirct_revenue_df.sort_values(by='Revenue',ascending=False).plot.pie(legend=False, subplots=True, autopct='%.2f%%', figsize=(8,8), explode=explode,colors = colors)
    plt.ylabel('')
    plt.title('Revenue Contribution Made by Top 10 Directos', weight='bold', fontsize=16)




.. parsed-literal::

    <matplotlib.text.Text at 0x7efe4e2e5e10>




.. image:: output_50_1.png


**Sorted out the top 10 Actors based on their movie count and have calculated the total revenue obtained from them.**
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    # creating a index of top 10 lead_role who has done most films
    most_active_hero = movies['lead_role'].value_counts().sort_values(ascending=False).head(10)
    most_active_heros = most_active_hero.index

.. code:: ipython3

    # calcuating the revenue made by the top the lead roles
    hero_total_revenue = np.zeros(len(most_active_heros))
    i = 0 
    for hero in most_active_heros:
        current_hero = movies['lead_role'].str.contains(hero).fillna(False)
        revenue_hero = movies[current_hero].revenue_in_billion.sum()
        hero_total_revenue[i] = revenue_hero 
        i += 1
        print (hero,revenue_hero)    


.. parsed-literal::

    Nicolas Cage 3.6068694389999996
    Robert De Niro 2.475179038
    Bruce Willis 5.002108683
    Clint Eastwood 1.698807639
    Johnny Depp 6.418930301000001
    Tom Hanks 7.774265766000002
    Sylvester Stallone 3.878945348
    Jean-Claude Van Damme 0.569362549
    Steven Seagal 0.5578430129999999
    John Travolta 2.8363024240000003


.. code:: ipython3

    # Creating DataFrame for a clear view and analysis 
    hero_revenue_df = pd.DataFrame(hero_total_revenue, index = most_active_heros, columns=['Revenue'])
    hero_revenue_df




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Revenue</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>Nicolas Cage</th>
          <td>3.606869</td>
        </tr>
        <tr>
          <th>Robert De Niro</th>
          <td>2.475179</td>
        </tr>
        <tr>
          <th>Bruce Willis</th>
          <td>5.002109</td>
        </tr>
        <tr>
          <th>Clint Eastwood</th>
          <td>1.698808</td>
        </tr>
        <tr>
          <th>Johnny Depp</th>
          <td>6.418930</td>
        </tr>
        <tr>
          <th>Tom Hanks</th>
          <td>7.774266</td>
        </tr>
        <tr>
          <th>Sylvester Stallone</th>
          <td>3.878945</td>
        </tr>
        <tr>
          <th>Jean-Claude Van Damme</th>
          <td>0.569363</td>
        </tr>
        <tr>
          <th>Steven Seagal</th>
          <td>0.557843</td>
        </tr>
        <tr>
          <th>John Travolta</th>
          <td>2.836302</td>
        </tr>
      </tbody>
    </table>
    </div>



Top 10 Actors who has made Highest Revenue Overall 
---------------------------------------------------

Calcuation for the percentage of revenue contribution of top 10 actors
have been made on above cell, for a better visualization i have made a
pie chart analysis of the top 10 actors from that visualization **Tom
Hank** and **Johnny Depp** has made the highest revenue percentage with
22.33% and 18.44%.

.. code:: ipython3

    #pie chart analysis on the heros contribution in revenue from highest to the lowest
    explode = np.linspace(0,0.4, 10)
    colors = ['#ff3232', '#ff4c4c', '#ff6666', '#ff7f7f', '#ff9999' ]
    hero_revenue_df.sort_values(by='Revenue',ascending=False).plot.pie(legend=False, subplots=True, autopct='%.2f%%', figsize=(8,8), explode=explode,colors = colors)
    plt.ylabel('')
    plt.title('Revenue Contribution Made by Top 10 Hero"s', weight='bold', fontsize=16)




.. parsed-literal::

    <matplotlib.text.Text at 0x7efe4ee51748>




.. image:: output_56_1.png


Finialized Conclusion on the Analysis
-------------------------------------

From all the analysis made on the Movies and their Genre , conclusion hits on two basics for movie Making,
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-  **Business Prespective**
-  **Awards Prespective**

-  **Business Prespective:**
-  Based on the Business Prespective, movies can gain more revenues
   based on the follwing Charateristics

   -  Budget
   -  Genre
   -  Lead Role (said to be as hero)
   -  Runtime So from the given data basd on the business prespective
      movies with high budget, genre like Adventure,science
      Fiction,Action and Fantasy, based on the lead role and the run
      time a movie can make a great business in return for the
      investment.

-  **Awards Prespective:**
-  Awards Prespective movis have the following charateristics
-  Genre
-  Runtime
-  Budget So from the award Prespective movies mostly depends on the
   genres like documentary, History, Animation, Fantasy and Music
   because they have the higest voting average, then comes the runtime
   of the movie which should not drag, at last comes the budget, where
   awards to a movie can only from the voting rate and these voting rate
   solely depends on the genre of movie.

Limitations
===========

-  Datasets had some missing values which was replaced it will zeros for
   numerical values and in some had missing values on the movie\_title
   and genre those rows have been removed since those cannot contribute
   to the analysis.
-  Dataset had some limitation on making the Exploration and Statistical
   analysis, where it could have been better with some more variables
   mentioning which **season movie was released**, **movie promotion
   budget**, and now a days social handling gives more hype for a movie,
   so there could have been **number of social media post and handling
   for a moive**
-  These variables could have given more insights on the data to come
   with a prediction of answering better for the questions based on,
-  popularity
-  Revenue
-  Rating
-  Final, limitation which i could say is, this is a single dataset
   which gives movies rating and votings from the IMDB movies alone, so
   this is constrained only from the IMDB user's review and rating but
   not the entire people who watched the film, so these analysis can
   predict only to an extend but not entirely.
